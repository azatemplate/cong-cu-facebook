<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/fb_api.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
    $page_id = isset($_GET['page_id']) ? $_GET['page_id'] : '';
    
    if (!$user_id || empty($page_id)) {
        echo json_encode(['status' => 'error', 'msg' => 'Vui lòng chọn đầy đủ User và Fanpage.']);
        exit;
    }

    $stmt = $pdo->prepare("SELECT access_token FROM pages WHERE page_id = ? AND user_id = ?");
    $stmt->execute([$page_id, $user_id]);
    $page = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$page || empty($page['access_token'])) {
        echo json_encode(['status' => 'error', 'msg' => 'Không tìm thấy Token của Fanpage này.']);
        exit;
    }

    $page_access_token = decryptData($page['access_token']);

    $after = isset($_GET['after']) ? $_GET['after'] : '';

    // Lấy danh sách conversations
    $endpoint = $page_id . '/conversations';
    $params = [
        'fields' => 'id,updated_time,unread_count,tags{name},participants{id,name,email,custom_labels},messages.limit(5){message,from}',
        'access_token' => $page_access_token,
        'limit' => 20
    ];

    if ($after) {
        $params['after'] = $after;
    }

    $response = fb_api_request($endpoint, $params, 'GET');

    if ($response['status_code'] === 200) {
        $next_cursor = '';
        if (isset($response['data']['paging']['cursors']['after'])) {
            $next_cursor = $response['data']['paging']['cursors']['after'];
        }
        echo json_encode(['status' => 'success', 'data' => $response['data']['data'], 'next_cursor' => $next_cursor, 'page_access_token' => $page_access_token]);
    } else {
        $error_msg = isset($response['data']['error']['message']) ? $response['data']['error']['message'] : 'Lỗi không xác định';
        echo json_encode(['status' => 'error', 'msg' => $error_msg]);
    }
} else {
    echo json_encode(['status' => 'error', 'msg' => 'Method not allowed']);
}
?>
