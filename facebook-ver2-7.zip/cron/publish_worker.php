<?php
// cron/publish_worker.php

// This file is meant to be run via CLI or triggered by a Windows Task Scheduler/cronjob
// e.g., php d:\pagespeed\hi\facebook\cron\publish_worker.php

$lock_file = sys_get_temp_dir() . '/facebook_publish_worker.lock';
$lock_fp = fopen($lock_file, 'c');
if (!flock($lock_fp, LOCK_EX | LOCK_NB)) {
    echo "Tiến trình đăng bài (publish_worker.php) đang chạy, vui lòng đợi...\n";
    exit;
}

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/fb_api.php';
require_once __DIR__ . '/../includes/drive_utils.php';
require_once __DIR__ . '/../includes/ai_rewriter.php';

echo "-------------------------------------------\n";
echo "Bắt đầu quét các bài viết lên lịch lúc: " . date('Y-m-d H:i:s') . "\n";

// ── Reset stuck 'processing' posts back to 'pending' ─────────────────────
// If a previous worker run crashed, posts stay at 'processing' forever.
// We reset them so they can be retried.
try {
    $stuck = $pdo->exec("UPDATE scheduled_posts SET status='pending' WHERE status='processing' AND scheduled_time <= DATE_SUB(NOW(), INTERVAL 10 MINUTE)");
    if ($stuck > 0) echo "⚠ Reset $stuck bài bị kẹt ở trạng thái 'processing' về 'pending'.\n";
} catch (Exception $e) {}

// ── Detect available columns ─────────────────────────────────────────────
$has_fb_post_id = false;
$has_error_msg  = false;
$has_retry_count = false;
$has_comment_lines  = false;
$has_comment_at     = false;
$has_comment_status = false;
try {
    $col_q = $pdo->query("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='scheduled_posts' AND COLUMN_NAME IN ('fb_post_id','error_msg','retry_count','comment_lines','comment_at','comment_status')");
    $existing_cols = $col_q ? $col_q->fetchAll(PDO::FETCH_COLUMN) : [];
    $has_fb_post_id  = in_array('fb_post_id', $existing_cols);
    $has_error_msg   = in_array('error_msg', $existing_cols);
    $has_retry_count = in_array('retry_count', $existing_cols);
    $has_comment_lines  = in_array('comment_lines', $existing_cols);
    $has_comment_at     = in_array('comment_at', $existing_cols);
    $has_comment_status = in_array('comment_status', $existing_cols);
} catch (Exception $e) {}

// Fetch system settings for retry logic
$sys_retry_interval = 1;
$sys_max_retries    = 3;
try {
    $ss_stmt = $pdo->query("SELECT setting_key, setting_value FROM system_settings WHERE setting_key IN ('retry_interval_minutes', 'max_retries')");
    $settings = [];
    while ($row = $ss_stmt->fetch(PDO::FETCH_ASSOC)) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }
    $sys_retry_interval = isset($settings['retry_interval_minutes']) ? (int)$settings['retry_interval_minutes'] : 1;
    $sys_max_retries    = isset($settings['max_retries']) ? (int)$settings['max_retries'] : 3;
} catch (Exception $e) {}

// 1. Fetch pending posts where scheduled_time <= NOW()
$retry_clause = $has_retry_count
    ? "OR (status = 'failed' AND retry_count < $sys_max_retries)"
    : '';
$stmt = $pdo->prepare("SELECT * FROM scheduled_posts WHERE (status = 'pending' $retry_clause) AND scheduled_time <= NOW()");
$stmt->execute();
$pending_posts = $stmt->fetchAll(PDO::FETCH_ASSOC);


if (empty($pending_posts)) {
    echo "Không có bài viết nào cần đăng lúc này.\n";
    echo "-------------------------------------------\n";
    exit;
}

echo "Tìm thấy " . count($pending_posts) . " bài viết cần đăng.\n";

$account_published_today = [];
$account_limits = [];

foreach ($pending_posts as $post) {
    echo "Đang xử lý bài đăng ID: {$post['id']} - Loại: {$post['post_type']}\n";

    // 1.5. Check Daily Output Limit per Account
    $aid = $post['account_id'] ?? 0;
    if ($aid > 0) {
        if (!isset($account_limits[$aid])) {
            $l_stmt = $pdo->prepare("SELECT page_limit, role FROM system_accounts WHERE id = ?");
            $l_stmt->execute([$aid]);
            $acc_data = $l_stmt->fetch(PDO::FETCH_ASSOC);
            $account_limits[$aid] = ($acc_data && $acc_data['role'] !== 'admin') ? (int)$acc_data['page_limit'] : -1;
        }

        if (!isset($account_published_today[$aid])) {
            $c_stmt = $pdo->prepare("SELECT COUNT(id) FROM scheduled_posts WHERE account_id = ? AND status = 'published' AND DATE(scheduled_time) = CURDATE()");
            $c_stmt->execute([$aid]);
            $account_published_today[$aid] = (int)$c_stmt->fetchColumn();
        }

        if ($account_limits[$aid] !== -1 && $account_published_today[$aid] >= $account_limits[$aid]) {
            echo "   → Tài khoản ID $aid đã đạt giới hạn {$account_limits[$aid]} bài/ngày. Chuyển bài ID {$post['id']} sang ngày mai.\n";
            $pdo->prepare("UPDATE scheduled_posts SET scheduled_time = CONCAT(DATE_ADD(DATE(scheduled_time), INTERVAL 1 DAY), ' 00:01:00'), error_msg = 'Đã đạt giới hạn bài trong ngày, dời sang ngày tiếp theo' WHERE id = ?")->execute([$post['id']]);
            continue;
        }
    }

    // 2. Mark as processing to prevent duplicate cron runs from picking it up
    // We only update if status is still pending or failed. If 0 rows affected, another worker took it.
    $update_processing = $pdo->prepare("UPDATE scheduled_posts SET status = 'processing' WHERE id = ? AND status IN ('pending', 'failed')");
    $update_processing->execute([$post['id']]);
    if ($update_processing->rowCount() === 0) {
        echo "   → Bài ID {$post['id']} đã được tiến trình khác xử lý. Bỏ qua.\n";
        continue;
    }

    // 3. Fetch Page Access Token
    $page_stmt = $pdo->prepare("SELECT access_token FROM pages WHERE page_id = ?");
    $page_stmt->execute([$post['page_id']]);
    $page = $page_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$page || empty($page['access_token'])) {
        marKAsFailed($pdo, $post['id'], "Không tìm thấy token của page_id: {$post['page_id']}", $sys_max_retries, $sys_retry_interval);
        continue;
    }

    $page_access_token = decryptData($page['access_token']);

    // 4. Prepare payload
    $endpoint = '';
    $post_data = [];
    $params = ['access_token' => $page_access_token];
    
    // ── Detect multi-image JSON array in media_path ──────────────────────
    $multi_image_paths = null;
    $raw_media = $post['media_path'];
    if (!empty($raw_media) && $raw_media[0] === '[') {
        $decoded = @json_decode($raw_media, true);
        if (is_array($decoded) && count($decoded) > 1) {
            $multi_image_paths = $decoded;
        } elseif (is_array($decoded) && count($decoded) === 1) {
            $raw_media = $decoded[0]; // treat single-element array as single path
            $post['media_path'] = $raw_media;
        }
    }

    $is_drive = strpos($raw_media, 'drive:') === 0;
    $is_tiktok = strpos($raw_media, 'tiktok:') === 0;
    $has_media = false;
    $abs_media_path = '';
    $file_mime = '';
    $file_name = '';
    $temp_drive_file = null;
    $t_title_override = null;

    // ── Multi-image post: upload each photo as unpublished, then create feed post ──
    if ($multi_image_paths !== null && ($post['post_type'] === 'Image' || $post['post_type'] === 'Status')) {
        // Parse content / AI rewrite
        $parsed_content = @json_decode($post['content'], true);
        $p_desc = '';
        if (is_array($parsed_content) && isset($parsed_content['description'])) {
            $p_desc = $parsed_content['description'];
            $use_ai = isset($parsed_content['use_ai']) && $parsed_content['use_ai'];
            if ($use_ai && !empty($p_desc)) {
                $p_desc = rewrite_content_with_ai($p_desc, $post['account_id'], false);
            }
        } else {
            $p_desc = $post['content'];
        }
        $post['content'] = $p_desc;

        echo "   → Multi-image post: " . count($multi_image_paths) . " ảnh (đã xáo thứ tự)\n";

        $photo_ids = [];
        $temp_files_to_clean = [];

        foreach ($multi_image_paths as $mi_idx => $mi_path) {
            $mi_abs = '';
            $mi_mime = '';
            $mi_name = '';

            if (strpos($mi_path, 'drive:') === 0) {
                // Drive file
                $drive_file_id = substr($mi_path, 6);
                $drive_token = get_drive_access_token($pdo, $post['account_id']);
                if (!$drive_token) {
                    echo "   → Bỏ qua ảnh Drive (không có token): $mi_path\n";
                    continue;
                }
                $file_info = download_drive_file_temp($drive_token, $drive_file_id);
                if (isset($file_info['error'])) {
                    echo "   → Bỏ qua ảnh Drive (lỗi tải): " . $file_info['error'] . "\n";
                    continue;
                }
                $mi_abs = $file_info['path'];
                $mi_mime = $file_info['mime'];
                $mi_name = $file_info['name'];
                $temp_files_to_clean[] = $mi_abs;
            } else {
                // Local file
                $mi_abs = __DIR__ . '/../' . $mi_path;
                if (!file_exists($mi_abs)) {
                    echo "   → Bỏ qua ảnh (không tồn tại): $mi_path\n";
                    continue;
                }
                $mi_mime = mime_content_type($mi_abs) ?: 'image/jpeg';
                $mi_name = basename($mi_abs);
            }

            // Upload as unpublished photo
            $upload_data = [
                'source'    => new CURLFile($mi_abs, $mi_mime, $mi_name),
                'published' => 'false'
            ];
            $upload_res = fb_api_request($post['page_id'] . '/photos', ['access_token' => $page_access_token], 'POST', $upload_data);

            if ($upload_res['status_code'] === 200 && !empty($upload_res['data']['id'])) {
                $photo_ids[] = $upload_res['data']['id'];
                echo "   → Upload ảnh " . ($mi_idx + 1) . "/" . count($multi_image_paths) . " OK (ID: {$upload_res['data']['id']})\n";
            } else {
                $err = isset($upload_res['data']['error']['message']) ? $upload_res['data']['error']['message'] : 'Unknown';
                echo "   → Upload ảnh " . ($mi_idx + 1) . " thất bại: $err\n";
            }
        }

        // Cleanup temp drive files
        foreach ($temp_files_to_clean as $tf) {
            if (file_exists($tf)) @unlink($tf);
        }

        if (empty($photo_ids)) {
            marKAsFailed($pdo, $post['id'], "Không upload được ảnh nào trong multi-image post.", $sys_max_retries, $sys_retry_interval);
            continue;
        }

        // Create multi-photo feed post with attached_media
        $feed_data = [];
        if (!empty($p_desc)) $feed_data['message'] = $p_desc;
        foreach ($photo_ids as $pi => $pid) {
            $feed_data["attached_media[$pi]"] = json_encode(['media_fbid' => $pid]);
        }

        $response = fb_api_request($post['page_id'] . '/feed', ['access_token' => $page_access_token], 'POST', $feed_data);
        $endpoint = 'multi_photo_feed';

        // Skip the normal single-file flow below
        goto handle_response;
    }

    if ($is_drive) {
        $drive_file_id = substr($post['media_path'], 6);
        $drive_token = get_drive_access_token($pdo, $post['account_id']);
        if (!$drive_token) {
            marKAsFailed($pdo, $post['id'], "Không thể lấy Google Access Token. Có thể Admin chưa liên kết.", $sys_max_retries, $sys_retry_interval);
            continue;
        }
        
        $file_info = download_drive_file_temp($drive_token, $drive_file_id);
        if (isset($file_info['error'])) {
            marKAsFailed($pdo, $post['id'], "Lỗi tải Google Drive: " . $file_info['error'], $sys_max_retries, $sys_retry_interval);
            continue;
        }
        
        $has_media = true;
        $abs_media_path = $file_info['path'];
        $file_mime = $file_info['mime'];
        $file_name = $file_info['name'];
        $t_title_override = pathinfo($file_name, PATHINFO_FILENAME);
        $temp_drive_file = $abs_media_path;
        
    } elseif ($is_tiktok) {
        $tiktok_url = substr($post['media_path'], 7);
        $api_response = @file_get_contents("https://hongvippro.com/apidowntik/api-dow-tik.php?url=" . urlencode($tiktok_url));
        $tik_data = json_decode($api_response, true);
        
        if (!$tik_data || !isset($tik_data['download_url'])) {
            marKAsFailed($pdo, $post['id'], "Không thể kết nối API tải video TikTok.", $sys_max_retries, $sys_retry_interval);
            continue;
        }
        
        $tik_title = isset($tik_data['title']) ? $tik_data['title'] : '';
        $t_title_override = $tik_title;
        
        $post_data['file_url'] = $tik_data['download_url'];
    } else {
        $has_media = !empty($post['media_path']) && file_exists(__DIR__ . '/../' . $post['media_path']);
        if ($has_media) {
            $abs_media_path = __DIR__ . '/../' . $post['media_path'];
            $file_mime = mime_content_type($abs_media_path);
            if (!$file_mime)
                $file_mime = 'application/octet-stream';
            $file_name = basename($abs_media_path);
            $t_title_override = pathinfo($file_name, PATHINFO_FILENAME);
        }
    }

    if ($has_media && file_exists($abs_media_path)) {
        $post_data['source'] = new CURLFile($abs_media_path, $file_mime, $file_name);
    }

    $post_type = $post['post_type'];

    if ($post_type === 'Status' || $post_type === 'Image') {
        $endpoint = ($post_type === 'Status') ? $post['page_id'] . '/feed' : $post['page_id'] . '/photos';
        
        $parsed_content = @json_decode($post['content'], true);
        if (is_array($parsed_content) && isset($parsed_content['description'])) {
            $p_desc = $parsed_content['description'];
            $use_ai = isset($parsed_content['use_ai']) && $parsed_content['use_ai'];
            
            if ($use_ai && !empty($p_desc)) {
                $p_desc = rewrite_content_with_ai($p_desc, $post['account_id'], false);
            }
            $post_data['message'] = $p_desc;
            $post['content'] = $p_desc;
        } else {
            $post_data['message'] = $post['content'];
        }
    }
    elseif ($post_type === 'Video' || $post_type === 'Reel') {
        $endpoint = $post['page_id'] . '/videos';
        // Content might be JSON encoded with title and description for Videos
        if ($post['content']) {
            $content_data = json_decode($post['content'], true);
            if (is_array($content_data)) {
                $p_desc = isset($content_data['description']) ? $content_data['description'] : '';
                $p_title = isset($content_data['title']) ? $content_data['title'] : '';
                $is_auto = isset($content_data['auto_title']) && $content_data['auto_title'];
                $use_ai = isset($content_data['use_ai']) && $content_data['use_ai'];
                
                if ($is_auto) {
                    if (empty($p_desc) && !empty($t_title_override)) $p_desc = $t_title_override;
                    // Không tự động gán text dài vào $p_title để tránh bị Facebook Graph API cắt bớt hiển thị "..."
                    if (empty($p_title) && !empty($t_title_override)) $p_title = '';
                }
                
                if ($use_ai) {
                    if (!empty($p_desc)) $p_desc = rewrite_content_with_ai($p_desc, $post['account_id'], false);
                    if (!empty($p_title) && $post_type !== 'Reel') $p_title = rewrite_content_with_ai($p_title, $post['account_id'], true);
                }
                
                if (!empty($p_desc)) $post_data['description'] = $p_desc;
                if (!empty($p_title) && $post_type !== 'Reel') $post_data['title'] = $p_title;
                
                // Keep content intact for history reference
                $post['content'] = $p_desc;
            }
            else {
                $p_desc = !empty($post['content']) ? $post['content'] : $t_title_override;
                if (!empty($p_desc)) $post_data['description'] = $p_desc;
                $post['content'] = $p_desc;
            }
        } else {
            if (!empty($t_title_override)) {
                $post_data['description'] = $t_title_override;
                // Không gán vào array $post_data['title'] vì FB giới hạn độ dài title Rất Ngắn và sẽ tự cắt kèm "..."
                $post['content'] = $t_title_override;
            }
        }
    }
    elseif (strpos($post_type, 'Story') !== false) {
        // Nếu là Drive, post_type chỉ ghi là 'Story'. Cần parse lại dựa vào mime
        if ($post_type === 'Story' && $has_media) {
            $is_photo = strpos($file_mime, 'image') !== false;
            $post_type = 'Story (' . ($is_photo ? 'Image' : 'Video') . ')';
        }
        
        $is_photo_story = strpos($post_type, 'Image') !== false;
        
        $response = fb_upload_story($post['page_id'], $page_access_token, $abs_media_path, $file_mime, $is_photo_story, $file_name);
        
        // Cần giả lập biến $endpoint để không lỗi đoạn dưới (hoặc skip)
        $endpoint = "story_uploaded";
    }
    else {
        marKAsFailed($pdo, $post['id'], "Loại bài đăng không hỗ trợ: $post_type", $sys_max_retries, $sys_retry_interval);
        if ($temp_drive_file && file_exists($temp_drive_file)) @unlink($temp_drive_file);
        continue;
    }

    // 5. Call API
    set_time_limit(300); // Allow long upload for videos
    if (strpos($post_type, 'Story') === false) {
        $response = fb_api_request($endpoint, $params, 'POST', $post_data);
    }

    handle_response:
    $post_id = $response['data']['id'] ?? $response['data']['post_id'] ?? null;

    if ($response['status_code'] === 200 && $post_id) {
        // Mark as published + save fb_post_id (if column exists)
        if ($has_fb_post_id) {
            $pdo->prepare("UPDATE scheduled_posts SET status = 'published', fb_post_id = ? WHERE id = ?")
                ->execute([$post_id, $post['id']]);
        } else {
            $pdo->prepare("UPDATE scheduled_posts SET status = 'published' WHERE id = ?")
                ->execute([$post['id']]);
        }

        // Schedule comment if needed (120s after now)
        if ($has_comment_lines && $has_comment_at && !empty($post['comment_lines'])) {
            $comment_at = date('Y-m-d H:i:s', time() + 120);
            if ($has_comment_status) {
                $pdo->prepare("UPDATE scheduled_posts SET comment_at = ?, comment_status = 'pending' WHERE id = ?")
                    ->execute([$comment_at, $post['id']]);
            } else {
                $pdo->prepare("UPDATE scheduled_posts SET comment_at = ? WHERE id = ?")
                    ->execute([$comment_at, $post['id']]);
            }
        }

        // Insert history (fault-tolerant)
        try {
            $display_content = $post['content'];
            $h_stmt = $pdo->prepare("INSERT INTO posts_history (page_id, post_type, content, fb_post_id) VALUES (?, ?, ?, ?)");
            $h_stmt->execute([$post['page_id'], $post_type, $display_content, $post_id]);
        } catch (Exception $e) {
            // posts_history table may not exist
        }

        // Xóa local file nếu là Local Scheduler File (uploads/...) - Không xóa file hệ thống
        if (!$is_drive && $has_media && file_exists($abs_media_path) && strpos($abs_media_path, 'uploads/') !== false) {
            @unlink($abs_media_path);
        }

        if ($aid > 0 && isset($account_published_today[$aid])) {
            $account_published_today[$aid]++;
        }

        echo " -> Thành công! Post ID: $post_id\n";
    }
    else {
        $error_msg = isset($response['data']['error']['message']) ? $response['data']['error']['message'] : json_encode($response['data']);
        marKAsFailed($pdo, $post['id'], "Lỗi API: $error_msg", $sys_max_retries, $sys_retry_interval, $has_error_msg, $has_retry_count);
    }
    
    // Always cleanup temp drive file for this iteration
    if ($temp_drive_file && file_exists($temp_drive_file)) {
        @unlink($temp_drive_file);
    }
}

echo "Hoàn thành phiên quét.\n";
echo "-------------------------------------------\n";

// ── Run Comment Worker inline ─────────────────────────────────────────────
require_once __DIR__ . '/comment_worker.php';

// ── Auto-cleanup: xóa dữ liệu cũ đã đăng thành công > 30 ngày ───────────
// Chạy tự động mỗi lần cron quét, nhưng chỉ thực thi 1 lần mỗi ngày
$cleanup_flag = sys_get_temp_dir() . '/fb_cleanup_' . date('Y-m-d') . '.done';
if (!file_exists($cleanup_flag)) {
    echo "\n--- Auto-Cleanup (>30 ngày) ---\n";
    $cleanup_stats = ['scheduled_posts' => 0, 'posts_history' => 0, 'campaigns' => 0, 'media_files' => 0];

    try {
        // 1. Xóa media files của bài đã published > 30 ngày
        $media_q = $pdo->query("SELECT media_path FROM scheduled_posts WHERE status = 'published' AND scheduled_time < DATE_SUB(NOW(), INTERVAL 30 DAY) AND media_path IS NOT NULL AND media_path != ''");
        if ($media_q) {
            foreach ($media_q->fetchAll(PDO::FETCH_COLUMN) as $mp) {
                $decoded = @json_decode($mp, true);
                $paths = is_array($decoded) ? $decoded : [$mp];
                foreach ($paths as $p) {
                    $p = trim($p);
                    if (strpos($p, 'uploads/') !== false) {
                        $full = __DIR__ . '/../' . $p;
                        if (file_exists($full) && is_file($full)) {
                            @unlink($full);
                            $cleanup_stats['media_files']++;
                        }
                    }
                }
            }
        }

        // 2. Xóa scheduled_posts đã published > 30 ngày
        $del1 = $pdo->exec("DELETE FROM scheduled_posts WHERE status = 'published' AND scheduled_time < DATE_SUB(NOW(), INTERVAL 30 DAY)");
        $cleanup_stats['scheduled_posts'] = (int)$del1;

        // 3. Xóa posts_history > 30 ngày
        try {
            $del2 = $pdo->exec("DELETE FROM posts_history WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)");
            $cleanup_stats['posts_history'] = (int)$del2;
        } catch (Exception $e) {}

        // 4. Xóa campaigns rỗng (không còn scheduled_posts nào)
        try {
            $del3 = $pdo->exec("DELETE FROM post_campaigns WHERE id NOT IN (SELECT DISTINCT campaign_id FROM scheduled_posts WHERE campaign_id IS NOT NULL)");
            $cleanup_stats['campaigns'] = (int)$del3;
        } catch (Exception $e) {}

        $total = array_sum($cleanup_stats);
        if ($total > 0) {
            echo "Đã dọn: {$cleanup_stats['scheduled_posts']} bài cũ, {$cleanup_stats['posts_history']} lịch sử, {$cleanup_stats['campaigns']} chiến dịch rỗng, {$cleanup_stats['media_files']} file media.\n";
        } else {
            echo "Không có dữ liệu cũ cần dọn.\n";
        }
        echo "----------------------------\n";

        // Đánh dấu đã chạy cleanup hôm nay
        @file_put_contents($cleanup_flag, date('Y-m-d H:i:s'));

        // Xóa flag cũ của ngày hôm qua
        $yesterday_flag = sys_get_temp_dir() . '/fb_cleanup_' . date('Y-m-d', strtotime('-1 day')) . '.done';
        if (file_exists($yesterday_flag)) @unlink($yesterday_flag);

    } catch (Exception $e) {
        echo "Lỗi cleanup: " . $e->getMessage() . "\n";
    }
}

function marKAsFailed($pdo, $id, $msg, $max_retries = 3, $retry_interval = 1, $has_error_msg = true, $has_retry_count = true)
{
    $current_retry = 0;
    if ($has_retry_count) {
        try {
            $sel = $pdo->prepare("SELECT retry_count FROM scheduled_posts WHERE id = ?");
            $sel->execute([$id]);
            $row = $sel->fetch(PDO::FETCH_ASSOC);
            $current_retry = $row ? (int)$row['retry_count'] : 0;
        } catch (Exception $e) { $has_retry_count = false; }
    }
    $new_retry = $current_retry + 1;

    echo " -> Lỗi: $msg (Lần thử: $new_retry/$max_retries)\n";

    // Build dynamic UPDATE based on available columns
    if ($has_error_msg && $has_retry_count) {
        if ($new_retry <= $max_retries) {
            $pdo->prepare("UPDATE scheduled_posts SET status='failed', error_msg=?, retry_count=?, scheduled_time=DATE_ADD(NOW(), INTERVAL ? MINUTE) WHERE id=?")
                ->execute([$msg, $new_retry, $retry_interval, $id]);
        } else {
            $pdo->prepare("UPDATE scheduled_posts SET status='failed', error_msg=?, retry_count=? WHERE id=?")
                ->execute([$msg, $new_retry, $id]);
        }
    } elseif ($has_error_msg) {
        $pdo->prepare("UPDATE scheduled_posts SET status='failed', error_msg=? WHERE id=?")
            ->execute([$msg, $id]);
    } else {
        $pdo->prepare("UPDATE scheduled_posts SET status='failed' WHERE id=?")
            ->execute([$id]);
    }
}
?>
