<?php
// cron/comment_worker.php
// Posts scheduled comments on published posts where comment_at <= NOW() and comment_done = 0
// Called automatically at end of publish_worker.php

$comment_lock_file = sys_get_temp_dir() . '/facebook_comment_worker.lock';
$comment_lock_fp = fopen($comment_lock_file, 'c');
if (!flock($comment_lock_fp, LOCK_EX | LOCK_NB)) {
    echo "Tiến trình comment_worker đang chạy, vui lòng đợi...\n";
    return;
}

if (!isset($pdo)) require_once __DIR__ . '/../includes/db.php';
if (!function_exists('fb_api_request')) require_once __DIR__ . '/../includes/fb_api.php';

echo "\n--- Comment Worker ---\n";

// Detect if comment_status column exists
$has_comment_status = false;
try {
    $col_q = $pdo->query("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='scheduled_posts' AND COLUMN_NAME='comment_status'");
    $has_comment_status = ($col_q && $col_q->fetchColumn() > 0);
} catch (Exception $e) {}

try {
    $stmt = $pdo->prepare("
        SELECT sp.id, sp.fb_post_id, sp.comment_lines, sp.page_id
        FROM scheduled_posts sp
        WHERE sp.status = 'published'
          AND sp.comment_lines IS NOT NULL
          AND sp.comment_at IS NOT NULL
          AND sp.comment_at <= NOW()
          AND sp.comment_done = 0
        LIMIT 50
    ");
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Bảng chưa có cột comment — chạy migrate.php trước.\n";
    return;
}

if (empty($rows)) {
    echo "Không có comment nào cần đăng lúc này.\n";
    echo "----------------------\n";
    return;
}

echo "Tìm thấy " . count($rows) . " bài cần bình luận.\n";

foreach ($rows as $row) {
    // Lock the row to prevent duplicate commenting from concurrent cron jobs
    $lock_stmt = $pdo->prepare("UPDATE scheduled_posts SET comment_done = 2 WHERE id = ? AND comment_done = 0");
    $lock_stmt->execute([$row['id']]);
    if ($lock_stmt->rowCount() === 0) continue;

    $fb_post_id = $row['fb_post_id'];
    if (empty($fb_post_id)) {
        // Mark done with error status to avoid retrying forever with missing post_id
        if ($has_comment_status) {
            $pdo->prepare("UPDATE scheduled_posts SET comment_done = 1, comment_status = 'error' WHERE id = ?")
                ->execute([$row['id']]);
        } else {
            $pdo->prepare("UPDATE scheduled_posts SET comment_done = 1 WHERE id = ?")
                ->execute([$row['id']]);
        }
        echo " -> Bỏ qua ID {$row['id']}: không có fb_post_id.\n";
        continue;
    }

    // Pick random line
    $lines = array_values(array_filter(array_map('trim', explode("\n", $row['comment_lines']))));
    if (empty($lines)) {
        if ($has_comment_status) {
            $pdo->prepare("UPDATE scheduled_posts SET comment_done = 1, comment_status = 'error' WHERE id = ?")
                ->execute([$row['id']]);
        } else {
            $pdo->prepare("UPDATE scheduled_posts SET comment_done = 1 WHERE id = ?")
                ->execute([$row['id']]);
        }
        continue;
    }
    $comment_text = $lines[array_rand($lines)];

    // Get page token
    try {
        $p_stmt = $pdo->prepare("SELECT access_token FROM pages WHERE page_id = ?");
        $p_stmt->execute([$row['page_id']]);
        $page = $p_stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $page = null;
    }

    if (!$page || empty($page['access_token'])) {
        if ($has_comment_status) {
            $pdo->prepare("UPDATE scheduled_posts SET comment_done = 1, comment_status = 'error' WHERE id = ?")
                ->execute([$row['id']]);
        } else {
            $pdo->prepare("UPDATE scheduled_posts SET comment_done = 1 WHERE id = ?")
                ->execute([$row['id']]);
        }
        echo " -> Bỏ qua ID {$row['id']}: không tìm thấy token.\n";
        continue;
    }

    $page_access_token = decryptData($page['access_token']);

    // Post comment  /{post_id}/comments
    $response = fb_api_request(
        $fb_post_id . '/comments',
        ['access_token' => $page_access_token],
        'POST',
        ['message' => $comment_text]
    );

    if ($response['status_code'] === 200 && isset($response['data']['id'])) {
        if ($has_comment_status) {
            $pdo->prepare("UPDATE scheduled_posts SET comment_done = 1, comment_status = 'done' WHERE id = ?")
                ->execute([$row['id']]);
        } else {
            $pdo->prepare("UPDATE scheduled_posts SET comment_done = 1 WHERE id = ?")
                ->execute([$row['id']]);
        }
        echo " -> ID {$row['id']}: Bình luận thành công!\n";
    } else {
        $err = $response['data']['error']['message'] ?? json_encode($response['data']);
        if ($has_comment_status) {
            $pdo->prepare("UPDATE scheduled_posts SET comment_done = 1, comment_status = 'error' WHERE id = ?")
                ->execute([$row['id']]);
        } else {
            $pdo->prepare("UPDATE scheduled_posts SET comment_done = 1 WHERE id = ?")
                ->execute([$row['id']]);
        }
        echo " -> ID {$row['id']}: Lỗi bình luận: $err\n";
    }
}

echo "----------------------\n";
