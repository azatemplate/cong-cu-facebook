<?php
// actions/publish_story.php
error_reporting(0);
ob_start();
session_start();

// ── Auth Guard ────────────────────────────────────────────────────────────
if (!isset($_SESSION['account_id'])) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['status' => 'error', 'msg' => 'Chưa đăng nhập.']);
    exit;
}

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/fb_api.php';
require_once __DIR__ . '/../includes/drive_utils.php';

ob_end_clean();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'msg' => 'Yêu cầu không hợp lệ.']);
    exit;
}

$account_id          = $_SESSION['account_id'];
$user_id             = intval($_POST['user_id'] ?? 0);
$drive_file_ids_str  = trim($_POST['drive_file_id'] ?? '');
$comment_lines = isset($_POST['enable_comment']) && !empty(trim($_POST['comment_lines'] ?? ''))
    ? trim($_POST['comment_lines'])
    : null;

$page_ids = [];
if (isset($_POST['page_ids']) && is_array($_POST['page_ids'])) {
    $page_ids = $_POST['page_ids'];
} elseif (!empty($_POST['page_id'])) {
    $page_ids[] = $_POST['page_id'];
}

if (!$user_id || empty($page_ids)) {
    echo json_encode(['status' => 'error', 'msg' => 'Vui lòng chọn đầy đủ User và Fanpage.']);
    exit;
}

// ── Build Media Pool ──────────────────────────────────────────────────────
$media_pool = [];

if (!empty($drive_file_ids_str)) {
    foreach (array_filter(array_map('trim', explode(",", $drive_file_ids_str))) as $id) {
        $media_pool[] = ['type' => 'drive', 'id' => $id];
    }
}

if (isset($_FILES['media']) && is_array($_FILES['media']['name'])) {
    for ($i = 0; $i < count($_FILES['media']['name']); $i++) {
        if ($_FILES['media']['error'][$i] === UPLOAD_ERR_OK) {
            $media_pool[] = [
                'type'     => 'local',
                'tmp_name' => $_FILES['media']['tmp_name'][$i],
                'name'     => $_FILES['media']['name'][$i],
                'mime'     => mime_content_type($_FILES['media']['tmp_name'][$i])
            ];
        }
    }
} elseif (empty($media_pool) && isset($_FILES['media']) && !is_array($_FILES['media']['name']) && $_FILES['media']['error'] === UPLOAD_ERR_OK) {
    $media_pool[] = [
        'type'     => 'local',
        'tmp_name' => $_FILES['media']['tmp_name'],
        'name'     => $_FILES['media']['name'],
        'mime'     => mime_content_type($_FILES['media']['tmp_name'])
    ];
}

if (empty($media_pool)) {
    echo json_encode(['status' => 'error', 'msg' => 'Vui lòng cung cấp ít nhất 1 File (Ảnh/Video hoặc từ Google Drive).']);
    exit;
}

// ── Schedule Matrix ───────────────────────────────────────────────────────
$start_date = trim($_POST['start_date'] ?? '');
$end_date   = trim($_POST['end_date'] ?? '');
$time_slots = trim($_POST['time_slots'] ?? '');
$schedule_dates = [];

if (!empty($start_date) && !empty($end_date) && !empty($time_slots)) {
    $slots   = array_filter(array_map('trim', explode(',', $time_slots)));
    $current = strtotime($start_date);
    $end     = strtotime($end_date);
    if ($current && $end && $current <= $end) {
        while ($current <= $end) {
            foreach ($slots as $slot) {
                $schedule_dates[] = date('Y-m-d', $current) . ' ' . $slot . ':00';
            }
            $current = strtotime('+1 day', $current);
        }
    }
}

$upload_dir = __DIR__ . '/../uploads/';
if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);

// ── Helper: resolve media for story ──────────────────────────────────────
function resolve_story_media($media, $upload_dir) {
    if ($media['type'] === 'drive') {
        return ['drive:' . $media['id'], 'Story'];
    }
    $is_photo  = strpos($media['mime'], 'image') !== false;
    $post_type = 'Story (' . ($is_photo ? 'Image' : 'Video') . ')';
    $ext       = pathinfo($media['name'], PATHINFO_EXTENSION) ?: ($is_photo ? 'jpg' : 'mp4');
    $filename  = uniqid('story_') . '.' . $ext;
    copy($media['tmp_name'], $upload_dir . $filename);
    return ['uploads/' . $filename, $post_type];
}

// ── Create Campaign (fault-tolerant) ─────────────────────────────────────
$campaign_id = null;
$first_time    = !empty($schedule_dates) ? $schedule_dates[0] : date('Y-m-d H:i:s');
$total_posts   = !empty($schedule_dates) ? count($schedule_dates) * count($page_ids) : count($page_ids);
$campaign_name = 'Story — ' . count($page_ids) . ' Pages';
if (!empty($schedule_dates)) {
    $campaign_name .= ' — ' . date('d/m', strtotime($start_date)) . '→' . date('d/m/Y', strtotime($end_date));
} else {
    $campaign_name .= ' — ' . date('d/m/Y H:i');
}
try {
    $camp_stmt = $pdo->prepare("INSERT INTO post_campaigns (account_id, name, post_type, total_posts, scheduled_time) VALUES (?, ?, ?, ?, ?)");
    $camp_stmt->execute([$account_id, $campaign_name, 'Story', $total_posts, $first_time]);
    $campaign_id = $pdo->lastInsertId();
} catch (PDOException $e) {
    // Table may not exist yet. Scheduling continues without campaign.
}

// ── Insert Posts ──────────────────────────────────────────────────────────
// Detect if campaign_id/comment_lines columns exist via INFORMATION_SCHEMA
$has_extra_cols = false;
try {
    $col_chk = $pdo->query("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='scheduled_posts' AND COLUMN_NAME='campaign_id'");
    $has_extra_cols = ($col_chk && $col_chk->fetchColumn() > 0);
} catch (Exception $e) { }

if (!$has_extra_cols) $campaign_id = null;

$s_stmt_with    = $has_extra_cols
    ? $pdo->prepare("INSERT INTO scheduled_posts (account_id, page_id, post_type, content, media_path, scheduled_time, status, campaign_id, comment_lines) VALUES (?, ?, ?, ?, ?, ?, 'pending', ?, ?)")
    : null;
$s_stmt_without = $pdo->prepare("INSERT INTO scheduled_posts (account_id, page_id, post_type, content, media_path, scheduled_time, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')");

$success_count  = 0;
$dates_to_use   = !empty($schedule_dates) ? $schedule_dates : [date('Y-m-d H:i:s')];

foreach ($dates_to_use as $datetime) {
    foreach ($page_ids as $p_id) {
        $media = $media_pool[array_rand($media_pool)];
        [$media_path, $post_type] = resolve_story_media($media, $upload_dir);
        if ($campaign_id !== null && $s_stmt_with !== null) {
            $s_stmt_with->execute([$account_id, $p_id, $post_type, 'Story', $media_path, $datetime, $campaign_id, $comment_lines]);
        } else {
            $s_stmt_without->execute([$account_id, $p_id, $post_type, 'Story', $media_path, $datetime]);
        }
        $success_count++;
    }
}

if (!empty($schedule_dates)) {
    echo json_encode(['status' => 'success', 'msg' => "Đã thả {$success_count} Story vào hàng đợi lên lịch hàng loạt!", 'campaign_id' => $campaign_id]);
} else {
    echo json_encode(['status' => 'success', 'msg' => "Đã đưa $success_count Story vào hàng đợi xử lý ngay.", 'redirect' => 'manage_posts.php', 'campaign_id' => $campaign_id]);
}
?>
