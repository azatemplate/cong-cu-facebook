<?php
// includes/ai_rewriter.php
require_once __DIR__ . '/db.php';

function clean_markdown($text) {
    // Basic markdown clean (if needed based on Python original)
    // Remove code blocks
    $text = preg_replace('/```[\s\S]*?```/', '', $text);
    // Remove inline code
    $text = preg_replace('/`[^`]*`/', '', $text);
    // Remove bold/italic markers
    $text = preg_replace('/(\*\*|__|\*|_)/', '', $text);
    // Remove hashes for headers
    $text = preg_replace('/^#+\s*/m', '', $text);
    $text = trim($text);
    return $text;
}

function ai_log($msg) {
    file_put_contents(__DIR__ . '/ai_debug.log', date('Y-m-d H:i:s') . " - " . $msg . "\n", FILE_APPEND);
}

function rewrite_content_with_gemini($prompt, $api_keys, $endpoint, $prompt_vaitro, $selected_model) {
    $base_url = rtrim($endpoint ?: "https://generativelanguage.googleapis.com/v1beta/models", '/');
    
    foreach ($api_keys as $key) {
        try {
            $url = $base_url . "/" . $selected_model . ":generateContent?key=" . $key;
            $combined_prompt = $prompt_vaitro ? str_replace("{prompt}", $prompt, $prompt_vaitro) : $prompt;
            
            $data = [
                "contents" => [
                    ["parts" => [["text" => $combined_prompt]]]
                ]
            ];
            
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            curl_setopt($ch, CURLOPT_TIMEOUT, 30);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            
            $response = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($http_code == 200) {
                $response_data = json_decode($response, true);
                $rewritten_text = $response_data['candidates'][0]['content']['parts'][0]['text'] ?? '';
                $rewritten_text = trim($rewritten_text);
                
                if (!empty($rewritten_text)) {
                    return $rewritten_text;
                }
            } else {
                ai_log("Gemini API error with key $key: HTTP $http_code - $response");
            }
        } catch (Exception $e) {
            ai_log("Gemini fetch exception with key $key: " . $e->getMessage());
            continue;
        }
    }
    return '';
}

function rewrite_content_with_openai($prompt, $api_keys, $endpoint, $prompt_vaitro, $selected_model) {
    $url = $endpoint ?: "https://api.openai.com/v1/chat/completions";
    
    foreach ($api_keys as $key) {
        try {
            $headers = [
                "Authorization: Bearer " . $key,
                "Content-Type: application/json"
            ];
            
            $messages = [];
            if ($prompt_vaitro) {
                $messages[] = ["role" => "system", "content" => str_replace("{prompt}", $prompt, $prompt_vaitro)];
            }
            $messages[] = ["role" => "user", "content" => $prompt];
            
            $data = [
                "model" => $selected_model,
                "messages" => $messages
            ];
            
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            curl_setopt($ch, CURLOPT_TIMEOUT, 30);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            
            $response = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($http_code == 200) {
                $response_data = json_decode($response, true);
                $rewritten_text = $response_data['choices'][0]['message']['content'] ?? '';
                $rewritten_text = trim($rewritten_text);
                
                if (!empty($rewritten_text)) {
                    return $rewritten_text;
                }
            } else {
                ai_log("OpenAI API error with key $key: HTTP $http_code - $response");
            }
        } catch (Exception $e) {
            ai_log("OpenAI fetch exception with key $key: " . $e->getMessage());
            continue;
        }
    }
    return '';
}

function rewrite_content_with_ai($content, $account_id, $is_title = false) {
    global $pdo;
    
    if (empty(trim($content))) return $content;

    try {
        $stmt = $pdo->prepare("SELECT provider, endpoint, api_keys, model, prompt_content, prompt_title FROM ai_configs WHERE account_id = ? AND is_active = 1 LIMIT 1");
        $stmt->execute([$account_id]);
        $config = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$config) {
            ai_log("AI Config is not active or not found for account $account_id");
            return $content; // fallback
        }
        
        $selected_ai = $config['provider'];
        $selected_model = $config['model'];
        $endpoint = $config['endpoint'];
        $api_keys_raw = decryptData($config['api_keys']);
        
        $prompt_vaitro = $is_title ? $config['prompt_title'] : $config['prompt_content'];
        
        if (empty($prompt_vaitro)) {
            ai_log("Missing prompt configuration (is_title=$is_title)");
            return $content;
        }
        
        // Parse API keys based on Python logic
        $api_keys = [];
        $api_keys_raw = trim($api_keys_raw);
        if (substr($api_keys_raw, 0, 1) === '[' || substr($api_keys_raw, 0, 1) === '(') {
            // Very simple bracket remover, assuming CSV inside
            $cleaned = trim($api_keys_raw, "()[]");
            $parts = explode(',', $cleaned);
            foreach ($parts as $p) {
                $p = trim($p, " '\"\n\r\t");
                if ($p) $api_keys[] = $p;
            }
        } else {
            $parts = explode(',', $api_keys_raw);
            foreach ($parts as $p) {
                $p = trim($p);
                if ($p) $api_keys[] = $p;
            }
        }
        
        if (empty($api_keys)) {
            ai_log("No API keys configured");
            return $content;
        }
        
        $rewritten_text = "";
        if ($selected_ai === "Gemini") {
            $rewritten_text = rewrite_content_with_gemini($content, $api_keys, $endpoint, $prompt_vaitro, $selected_model);
        } elseif ($selected_ai === "OpenAI") {
            $rewritten_text = rewrite_content_with_openai($content, $api_keys, $endpoint, $prompt_vaitro, $selected_model);
        } else {
            $rewritten_text = $content;
        }
        
        if (empty($rewritten_text)) {
            return $content;
        }
        
        return clean_markdown($rewritten_text);
        
    } catch (Exception $e) {
        ai_log("Error in rewrite_content_with_ai: " . $e->getMessage());
        return $content;
    }
}

function clean_json_response($text) {
    // Tìm đoạn text nằm giữa { và } hoặc [ và ]
    preg_match('/\{.*\}/s', $text, $matches);
    if (!empty($matches)) {
        return $matches[0];
    }
    return $text;
}

function rewrite_youtube_with_ai($content, $account_id) {
    global $pdo;
    
    if (empty(trim($content))) return null;

    try {
        $stmt = $pdo->prepare("SELECT provider, endpoint, api_keys, model, prompt_youtube FROM ai_configs WHERE account_id = ? AND is_active = 1 LIMIT 1");
        $stmt->execute([$account_id]);
        $config = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$config) {
            ai_log("AI Config not active for Youtube on account $account_id");
            return null;
        }
        
        $selected_ai = $config['provider'];
        $selected_model = $config['model'];
        $endpoint = $config['endpoint'];
        $api_keys_raw = decryptData($config['api_keys']);
        
        $system_prompt = !empty($config['prompt_youtube']) 
            ? $config['prompt_youtube'] 
            : "Bạn là một AI chuyên viết nội dung Youtube chuẩn SEO. Hãy viết Tiêu đề (dưới 100 ký tự), Mô tả chi tiết (bỏ các ký tự đặc biệt như *, ^, \"), và dạng Tags (cách nhau bằng dấu phẩy) dựa trên nội dung được cung cấp. LƯU Ý QUAN TRỌNG: Chỉ trả về ĐÚNG MỘT CHUỖI JSON có định dạng sau, KHÔNG GIẢI THÍCH, KHÔNG MARKDOWN:\n{\n  \"title\": \"Tiêu đề video chuẩn SEO\",\n  \"description\": \"Mô tả video hấp dẫn...\",\n  \"tags\": \"tag1, tag2, tag3\"\n}\n\nNội dung cần viết:\n{prompt}";
        
        $api_keys = [];
        $api_keys_raw = trim($api_keys_raw);
        if (substr($api_keys_raw, 0, 1) === '[' || substr($api_keys_raw, 0, 1) === '(') {
            $cleaned = trim($api_keys_raw, "()[]");
            $parts = explode(',', $cleaned);
            foreach ($parts as $p) {
                $p = trim($p, " '\"\n\r\t");
                if ($p) $api_keys[] = $p;
            }
        } else {
            $parts = explode(',', $api_keys_raw);
            foreach ($parts as $p) {
                $p = trim($p);
                if ($p) $api_keys[] = $p;
            }
        }
        
        if (empty($api_keys)) return null;
        
        $rewritten_text = "";
        if ($selected_ai === "Gemini") {
            $rewritten_text = rewrite_content_with_gemini($content, $api_keys, $endpoint, $system_prompt, $selected_model);
        } elseif ($selected_ai === "OpenAI") {
            $rewritten_text = rewrite_content_with_openai($content, $api_keys, $endpoint, $system_prompt, $selected_model);
        }
        
        if (empty($rewritten_text)) return null;
        
        $rewritten_text = clean_json_response($rewritten_text);
        
        $parsed = json_decode($rewritten_text, true);
        if (is_array($parsed) && isset($parsed['title']) && isset($parsed['description'])) {
            // Chuẩn hóa một lần nữa
            $parsed['description'] = preg_replace('/[*^"]/', '', $parsed['description']);
            // Xóa emoji
            $parsed['description'] = preg_replace('/[\x{1F600}-\x{1F64F}\x{1F300}-\x{1F5FF}\x{1F680}-\x{1F6FF}\x{2600}-\x{26FF}\x{2700}-\x{27BF}]/u', '', $parsed['description']);
            return $parsed;
        }
        return null;
        
    } catch (Exception $e) {
        ai_log("Error in rewrite_youtube_with_ai: " . $e->getMessage());
        return null;
    }
}
?>
