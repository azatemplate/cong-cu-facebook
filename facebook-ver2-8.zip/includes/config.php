<?php
// includes/config.php
// ============================================================
// Centralized configuration — edit this file only.
// KEEP THIS FILE OUTSIDE PUBLIC WEBROOT if possible,
// or at minimum protect it with .htaccess deny rules.
// ============================================================

// --- Database ---
define('DB_HOST', 'localhost');
define('DB_NAME', 'uethicaz_facebook');
define('DB_USER', 'uethicaz_facebook');
define('DB_PASS', '[U@7aebiI7b=36uz');
define('DB_CHARSET', 'utf8mb4');

// --- Encryption ---
// IMPORTANT: Change this key in production! Keep it secret.
define('ENCRYPTION_KEY', '!@#SystemKey2026FacebookApp#@!');

// --- Environment ---
// Set to 'production' on live server to enable SSL verification etc.
define('APP_ENV', 'production'); // 'development' | 'production'
?>
